/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_and_heredoc.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aboudjel <aboudjel@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/08 01:43:35 by aboudjel          #+#    #+#             */
/*   Updated: 2022/04/27 14:38:06 by aboudjel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include_bonus/pipex_bonus.h"

void	ft_heredoc(t_data *general)
{
	char	*tmp;
	int		fd;

	fd = open("./temp/heredoc.tmp", O_TRUNC | O_APPEND | O_CREAT | O_RDWR, 0000644);
	while (1)
	{
		write(1, ">", 1);
		tmp = get_next_line(0);
		if (ft_strncmp(tmp, general->limiter) == 3)
			break;
		write(fd, tmp, ft_strlen(tmp));
		free(tmp);
	}
	free(tmp);
	close(fd);
}

void	fd_and_hd(t_data *general, int argc, char **argv, int key)
{
	if (key == 1)
	{
		general->limiter = argv[2];
		ft_heredoc(general);
		general->infilefd = open("./temp/heredoc.tmp", O_RDONLY);
		general->outfilefd = open(argv[argc - 1], O_APPEND
			| O_CREAT | O_RDWR, 0000644);
		if (general->outfilefd < 0 || general->infilefd < 0)
			ft_error(general, 1);
	}
	else
	{
		general->heredoc = 0;
		general->infilefd = open(argv[1], O_RDONLY);
		if (general->infilefd < 0)
		{
			write(2,"no such file or directory: ", 27);
			write(2, argv[1], ft_strlen(argv[1]));
			write(2, "\n", 1);
		}
		general->outfilefd = open(argv[argc - 1],
			O_TRUNC | O_CREAT | O_RDWR, 0000644);
		if (general->outfilefd < 0)
			ft_error(general, 1);
	}
}
t_data	*initializing2(t_data *general, int max)
{
	int	j;

	j = 0;
	while (j < general->argc - max)
	{
		if (pipe(general->fd + j * 2) < 0)
			ft_error(general, 21);
		j++;
	}		
	general->pid = malloc(sizeof(int) * (general->argc - max + 1));
	if (!general->pid)
		ft_error(general, 21);
	j = 2;
	if (general->heredoc == 1)
		j = 3;
	general->lst = NULL;
	general->lst = ft_nodenew(general->argv[j], general);
	while (j < general->argc - 2)
	{
		j++;
		ft_nodeadd_back(general->lst,
			ft_nodenew(general->argv[j], general));
	}
	return (general);
}

t_data	*initializing(int argc, char *argv[], char *envp[], int	max)
{
	t_data	*general;

	general = malloc(sizeof(t_data));
	if (!general)
		ft_error(general, 0);
	if (ft_strncmp(argv[1], "here_doc") == 2)
	{
		general->heredoc = 1;
		fd_and_hd(general, argc, argv, 1);
	}
	else
		fd_and_hd(general, argc, argv, 0);	
	general->argc = argc;
	general->argv = argv;
	general->envp = envp;
	general->i = 0;
	general->returnvalue = 0;
	general->splitpath = NULL;
	if (general->heredoc == 1)
		max = 5;
	general->fd = malloc(sizeof(int) * (general->argc - max) * 2);
	if (!general->fd)
		ft_error(general, 2);
	return (initializing2(general, max));
}

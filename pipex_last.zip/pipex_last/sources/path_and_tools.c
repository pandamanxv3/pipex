/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   path_and_tools.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aboudjel <aboudjel@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/08 01:43:05 by aboudjel          #+#    #+#             */
/*   Updated: 2022/04/29 16:47:41 by aboudjel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/pipex.h"

void	ft_closeall(t_data *general)
{
	int	i;
	int	max;

	max = 4;
	if (general->heredoc == 1)
		max = 5;
	i = 0;
	while (i < (general->argc - max) * 2)
	{
		close(general->fd[i]);
		i++;
	}
}

void	ft_freeall(t_data *general)
{
	ft_nodeclear(general);
	if (general->splitpath)
		ft_splitfree(general->splitpath);
	free(general->pid);
	free(general->fd);
	free(general);
}

void	extractpath(t_data *general)
{
	int	i;

	i = 0;
	while (general->envp[i])
	{
		if (ft_strncmp(general->envp[i], "PATH="))
		{
			general->path = general->envp[i];
			return ;
		}
		i++;
	}
	ft_error(general, 5);
}

void	findpath(t_data *general)
{
	t_node	*tmp;
	int		returnvalue;
	int		i;

	tmp = general->lst;
	while (tmp)
	{
		i = 0;
		if (tmp->cmd[0] == NULL)
			tmp->path = NULL;
		else
		{
			ft_strjoin(tmp, tmp->path, tmp->cmd[0], general);
			returnvalue = -1;
			while (returnvalue == -1 && general->splitpath[i])
			{
				ft_strjoin(tmp, general->splitpath[i], "/", general);
				ft_strjoin(tmp, tmp->path, tmp->cmd[0], general);
				returnvalue = access(tmp->path, F_OK);
				i++;
			}
		}
		tmp = tmp->next;
	}
}

void	getpath(t_data *general)
{
	extractpath(general);
	ft_dispatchsplit(general);
	findpath(general);
}

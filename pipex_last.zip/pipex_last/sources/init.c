/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aboudjel <aboudjel@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/08 01:43:35 by aboudjel          #+#    #+#             */
/*   Updated: 2022/04/29 16:49:48 by aboudjel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/pipex.h"

size_t	ft_strlen(char *str)
{
	int	i;

	i = 0;
	if (!str)
		return (0);
	while (str[i])
		i++;
	return (i);
}

void	ft_fd(t_data *general, int argc, char **argv)
{
	general->heredoc = 0;
	general->infilefd = open(argv[1], O_RDONLY);
	if (general->infilefd < 0)
	{
		write(2, "no such file or directory: ", 27);
		write(2, argv[1], ft_strlen(argv[1]));
		write(2, "\n", 1);
	}
	general->outfilefd = open(argv[argc - 1],
			O_TRUNC | O_CREAT | O_RDWR, 0000644);
	if (general->outfilefd < 0)
		ft_error(general, 1);
}

t_data	*initializing2(t_data *general, int max)
{
	int	j;

	j = 0;
	while (j < general->argc - max)
	{
		if (pipe(general->fd + j * 2) < 0)
			ft_error(general, 21);
		j++;
	}		
	general->pid = malloc(sizeof(int) * (general->argc - max + 1));
	if (!general->pid)
		ft_error(general, 21);
	j = 2;
	general->lst = NULL;
	general->lst = ft_nodenew(general->argv[j], general);
	while (j < general->argc - 2)
	{
		j++;
		ft_nodeadd_back(general->lst,
			ft_nodenew(general->argv[j], general));
	}
	return (general);
}

t_data	*initializing(int argc, char *argv[], char *envp[], int max)
{
	t_data	*general;

	general = malloc(sizeof(t_data));
	if (!general)
		ft_error(general, 0);
	ft_fd(general, argc, argv);
	general->argc = argc;
	general->argv = argv;
	general->envp = envp;
	general->i = 0;
	general->returnvalue = 0;
	general->splitpath = NULL;
	general->fd = malloc(sizeof(int) * (general->argc - max) * 2);
	if (!general->fd)
		ft_error(general, 2);
	return (initializing2(general, max));
}

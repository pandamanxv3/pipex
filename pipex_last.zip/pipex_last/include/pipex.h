/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aboudjel <aboudjel@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/08 01:34:36 by aboudjel          #+#    #+#             */
/*   Updated: 2022/04/29 16:50:06 by aboudjel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PIPEX_H
# define PIPEX_H

# include <stdlib.h>
# include <sys/types.h>
# include <sys/wait.h>
# include <stdio.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include <stddef.h>
# include <errno.h>

# define ERR_ARG "invalid number of arguments\n"
# define ERR_ENV "no environnements detected\n"
# define ERR_SPLIT "split didn't work\n"
# define ERR_MAL "struct's malloc failed\n"
# define ERR_FD "allocating fd or pid failed\n"
# define ERR_FORK "fork didn't work"
# define ERR_OUT "outfile cannot open"
# define ERR_IN "infile cannot open"

# define BUFFER_SIZE 22048

typedef struct s_node
{
	char			**cmd;
	char			*path;
	struct s_node	*next;
}t_node;

typedef struct s_data {
	int		argc;
	char	**argv;
	char	**envp;
	char	*path;
	char	*limiter;
	char	**splitpath;
	t_node	*lst;
	pid_t	*pid;
	int		heredoc;
	int		fdhd[2];
	int		infilefd;
	int		outfilefd;
	int		*fd;
	int		i;
	int		returnvalue;
}t_data;

char	**ft_splitfree(char **tab);
char	**ft_split(char const *s, char c, unsigned int i);

char	*setupline(char *str, int fd);
char	*get_next_line(int fd);
char	*new_str(char *str);
char	*ft_strstrjoin(char *s1, char *s2, int j, int i);
char	*ft_strjoingnl(char *s1, char *s2);

t_node	*ft_nodenew(char *cmd, t_data *general);

t_data	*initializing(int argc, char *argv[], char *envp[], int max);
t_data	*initializing2(t_data *general, int max);

size_t	ft_strlen(char *str);

int		ft_strncmp(const char *s1, const char *s2);
int		ft_args(int argc, char **argv);
int		newline(char *str);
int		ft_checkendofline(char *buffer_save);

void	ft_freeall(t_data *general);
void	ft_fd(t_data *general, int argc, char **argv);
void	ft_heredoc(t_data *general);
void	ft_pipexdispatch(t_data *general);
void	ft_pipexout(t_data *general, t_node *lst);
void	ft_pipexloop(t_data *general, t_node *lst);
void	ft_pipexin(t_data *general, t_node *lst);
void	ft_closeall(t_data	*general);
void	ft_dup2(int in, int out);
void	ft_strjoin(t_node *lst, char *s1, char *s2, t_data *general);
void	ft_nodeclear(t_data *list);
void	ft_error3(t_data *general, int key);
void	ft_error2(t_data *general, int key);
void	ft_error(t_data *general, int key);
void	ft_nodeadd_back(t_node *lst, t_node *new);
void	ft_dispatchsplit(t_data *list);
void	extractpath(t_data *general);
void	findpath(t_data *general);
void	getpath(t_data *general);

#endif